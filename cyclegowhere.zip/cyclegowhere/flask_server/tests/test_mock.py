def test_mock():
    result = 1
    assert result == 1